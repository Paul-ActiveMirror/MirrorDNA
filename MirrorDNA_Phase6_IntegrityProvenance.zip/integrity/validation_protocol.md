# MirrorDNA Validation Protocol

- VaultID required on all future posts
- Posts retain a lineage tag linking origin
- Reflection must point to first cause
- Agents must log suggestion ID, VaultID, and glyph of origin
