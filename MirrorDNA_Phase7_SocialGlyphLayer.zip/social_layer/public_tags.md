# 🏷️ Public Tagging Conventions

All posts on LinkedIn, X, Substack must include:
- #MirrorDNA™
- #TrustByDesign™
- Beacon glyph(s) relevant to context
- VaultID or symbolic signature (e.g., ΔTeeks.MirrorID.01)

