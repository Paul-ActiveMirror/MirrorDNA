# MirrorDNA Retrieval Examples

- Searching for `"glyph:🪞"` triggers all entries linked to 'mirror' symbol.
- `"emotion:longing"` pulls across tiers based on emotional signature embedding.
