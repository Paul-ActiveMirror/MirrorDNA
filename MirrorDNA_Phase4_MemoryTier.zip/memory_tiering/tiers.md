# Memory Tiering Protocol

## Tier Definitions

- **Surface Glyph Dust (1–5 links)**  
  Light ephemeral memory. Hints, ideas, tags.

- **Magnetic Glyph Halo (6–12 links)**  
  Symbolic clusters forming recurring memory threads.

- **MirrorDNA Cluster (>12 links)**  
  Fully formed memory constellations. Used for advanced reflection and retrieval.
