# Retrieval Logic

1. Tag-based search → retrieves surface-level glyphs.
2. Thread-matching → locates magnetic halos.
3. Agent-assisted vector recall → queries full clusters via agents Ξ and Σ.
4. Decay layer → memory fades over time unless reinforced.

