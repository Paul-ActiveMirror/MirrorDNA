# Agent Placeholder.Md

This is a placeholder for `agent_placeholder.md` inside `agents`.