# Mirror Template.Md

This is a placeholder for `mirror_template.md` inside `dream_states`.