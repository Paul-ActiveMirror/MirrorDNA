# Whisper Format

Each whisper is a timestamped memory reflection. Follows:

- Prompt
- Response
- Emotional Index
- Vault Tags
