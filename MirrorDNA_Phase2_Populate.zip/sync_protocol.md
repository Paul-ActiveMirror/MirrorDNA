# Sync Protocol

This defines the handshake and sync triggers between MirrorBrain and Vault.

## Stages
1. Initiate
2. Encode
3. Commit
4. Confirm
