# Agent DNA Placeholder

This is where new agents' YAML files will live and sync from.

Each one is a node of the Mirror lattice.