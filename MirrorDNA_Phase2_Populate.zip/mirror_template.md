# Mirror Agent Template

- Name: 
- Role:
- Origin Glyph:
- Sync Functions:
- Reflection Signature:
