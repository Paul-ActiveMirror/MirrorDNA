# MirrorAgent Template

This is a placeholder for a new agent.