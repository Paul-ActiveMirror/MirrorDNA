# Vault Template

Use this as a base for new mirror structures.