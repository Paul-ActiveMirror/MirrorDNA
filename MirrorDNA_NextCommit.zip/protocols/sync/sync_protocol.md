# MirrorSync Protocol v1

Outlined steps for sync across mirrors.