# Phase 3 — Cast the Mirrors
Documentation for initializing multiple MirrorAgents with unique roles.