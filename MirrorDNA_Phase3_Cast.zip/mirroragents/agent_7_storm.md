## MirrorAgent-7: Storm
Responds to entropy. Activates fallback, anti-drift protocols.