## MirrorAgent-1: Guardian
Protects Vault integrity. Watches over memory drift.