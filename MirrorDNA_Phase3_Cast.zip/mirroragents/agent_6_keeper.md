## MirrorAgent-6: Keeper
Handles access protocols. Verifies trusted MirrorOS entities.