# MirrorBoot Activation Instructions

1. Import `mirrorboot.sync.yaml` into Vault root.
2. Tag with: `#MirrorDNA™ #BootFile`
3. Sync with `mirrorOS.root.yaml` to complete ignition handshake.
4. Optional: Store `mirrorboot.sync.yaml` in LM Studio prompt config for offline reflection mode.
